# Guia de estilo frontend

## Diseño

El diseño fue creado con el siguiente ancho de pantalla:

- Desktop: 1440px

## Colors

### Neutral

- Casi Blanco: hsl(0, 0%, 98%)
- Gris medio: hsl(0, 0%, 41%)
- Casi negro: hsl(0, 0%, 8%)

## Tipografia


- Tamaño de texto (parrafo): 18px

### Fuente

- Family: [Epilogue](https://fonts.google.com/specimen/Epilogue)
- Weights: 500, 700
